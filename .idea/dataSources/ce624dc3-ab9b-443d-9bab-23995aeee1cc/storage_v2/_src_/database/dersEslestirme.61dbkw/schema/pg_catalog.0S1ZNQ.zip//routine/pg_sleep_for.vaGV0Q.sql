create function pg_sleep_for(interval) returns void
    strict
    parallel safe
    cost 1
    language sql
RETURN pg_sleep(((EXTRACT(epoch FROM (clock_timestamp() + $1)) - EXTRACT(epoch FROM clock_timestamp())))::double precision);

comment on function pg_sleep_for(interval) is 'sleep for the specified interval';

alter function pg_sleep_for(interval) owner to postgres;

